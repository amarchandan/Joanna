from pyrogram import Client, filters
from plugins.func.users_sql import *

@Client.on_message(filters.command('add'))
async def cmd_add(Client, message):
    user_id = str(message.from_user.id)
    CEO = "1418571871"
    GROUP = insert_reg_data(group_id)
    if user_id != CEO:
        resp = "Require Owner Privilages ⚠️"
        msg1 = await message.reply_text(resp, message.id)
    else:
        chat_add = message.text[len('/add '):]
        if len(chat_add) == 0:
            chat_id = str(message.chat.id)
        else:
            chat_id = message.text[len('/add '):]
        groupid = chat_id
        if groupid in GROUP:
            resp = f"""
Group (<code>{groupid}</code>) Is Already Authorized ⚠️.
      """
            await message.reply_text(resp, message.id)
        else:
            GROUP = insert_reg_data(group_id)
            resp = f"""
Group (<code>{groupid}</code>) Is Now Authorized ✅.
      """
            await message.reply_text(resp, message.id)
